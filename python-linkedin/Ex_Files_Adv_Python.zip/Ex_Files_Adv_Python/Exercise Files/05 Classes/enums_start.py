# define enumerations using the Enum base class


def main():
    pass
    # TODO: enums have human-readable values and types

    # TODO: enums have name and value properties

    # TODO: print the auto-generated value

    # TODO: enums are hashable - can be used as keys


if __name__ == "__main__":
    main()
