# advanced iteration functions in the itertools package


def testFunction(x):
    pass


def main():
    # TODO: cycle iterator can be used to cycle over a collection
    seq1 = ["Joe", "John", "Mike"]

    # TODO: use count to create a simple counter

    # TODO: accumulate creates an iterator that accumulates values
    vals = [10,20,30,40,50,40,30]
            
    # TODO: use chain to connect sequences together
    
    # TODO: dropwhile and takewhile will return values until
    # a certain condition is met that stops them
    
    
if __name__ == "__main__":
    main()
    