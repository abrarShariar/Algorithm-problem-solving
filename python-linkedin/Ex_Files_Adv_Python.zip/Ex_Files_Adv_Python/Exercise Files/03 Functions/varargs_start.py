# Demonstrate the use of variable argument lists


# TODO: define a function that takes variable arguments
def addition():
    pass


def main():
    # TODO: pass different arguments
    print(addition())

    # TODO: pass an existing list


if __name__ == "__main__":
    main()
