# use iterator functions like enumerate, zip, iter, next


def main():
    # define a list of days in English and French
    days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
    daysFr = ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"]

    # TODO: use iter to create an iterator over a collection

    # TODO: iterate using a function and a sentinel

    # TODO: use regular interation over the days

    # TODO: using enumerate reduces code and provides a counter

    # TODO: use zip to combine sequences


if __name__ == "__main__":
    main()
