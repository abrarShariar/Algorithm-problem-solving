# deque objects are like double-ended queues

import collections
import string


def main():
    
    # TODO: initialize a deque with lowercase letters

    # TODO: deques support the len() function

    # TODO: deques can be iterated over

    # TODO: manipulate items from either end

    # TODO: rotate the deque


if __name__ == "__main__":
    main()
