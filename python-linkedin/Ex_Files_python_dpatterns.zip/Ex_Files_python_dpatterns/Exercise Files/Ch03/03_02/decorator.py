from functools import wraps

def make_blink(function):
	"""Defines the decorator"""

	#This makes the decorator transparent in terms of its name and docstring


	#Define the inner function
	def decorator():
		#Grab the return value of the function being decorated
		

		#Add new functionality to the function being decorated
		

	return decorator

#Apply the decorator here!

def hello_world():
	"""Original function! """

	return "Hello, World!"

#Check the result of decorating


#Check if the function name is still the same name of the function being decorated


#Check if the docstring is still the same as that of the function being decorated


