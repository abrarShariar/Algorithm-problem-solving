# use transform functions like sorted, filter, map


def filterFunc(x):
    pass


def filterFunc2(x):
    pass


def squareFunc(x):
    pass


def toGrade(x):
    pass


def main():
    # define some sample sequences to operate on
    nums = (1, 8, 4, 5, 13, 26, 381, 410, 58, 47)
    chars = "abcDeFGHiJklmnoP"
    grades = (81, 89, 94, 78, 61, 66, 99, 74)

    # TODO: use filter to remove items from a list

    # TODO: use filter on non-numeric sequence

    # TODO: use map to create a new sequence of values

    # TODO: use sorted and map to change numbers to grades


if __name__ == "__main__":
    main()
