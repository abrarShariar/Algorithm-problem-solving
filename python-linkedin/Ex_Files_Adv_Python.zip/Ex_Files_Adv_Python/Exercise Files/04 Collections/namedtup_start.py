# Demonstrate the usage of namdtuple objects

import collections


def main():
    # TODO: create a Point namedtuple

    # TODO: use _replace to create a new instance
    pass


if __name__ == "__main__":
    main()
